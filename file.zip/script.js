const downloadsButton =  document.getElementsByClassName("downloadButton")[0];
const reportBugButton =  document.getElementsByClassName("reportBugButton")[0];
const helpButton =  document.getElementsByClassName("helpButton")[0];
const logo =  document.getElementsByClassName("logo")[0];

logo.onclick = (event) => {
    document.location.href = "https://skitt.glitch.me/"
}

downloadsButton.onclick = (event) => {
    document.location.href = document.location + "/pages/downloads"
}
helpButton.onclick = (event) => {
    document.location.href = document.location + "/pages/help"
}

reportBugButton.onclick = (event) => {
    document.location.href = document.location + "/pages/reportBug"
}