const versions = document.querySelector('.versions')
const logo =  document.getElementsByClassName("logo")[0];

logo.onclick = (event) => {
    document.location.href = "https://skitt.glitch.me/"
}


class download{
  constructor(version, link){
    const element = document.createElement("button");
    //element.classList.add("downloadButton BUTTON HOVER_ENLARGE CLICK_SHRINK SMOOTH_ALL");
    element.classList.add("downloadButton")
    element.classList.add("BUTTON")
    element.classList.add("HOVER_ENLARGE")
    element.classList.add("CLICK_SHRINK")
    element.classList.add("SMOOTH_ALL")
    element.textContent = version;
    element.addEventListener("click", () => {

      downloadURI(link, "donwload")

    });

    console.log(element)
    versions.appendChild(element)
  }
}

function downloadURI(uri, name) 
{
    var link = document.createElement("a");
    // If you don't know the name or want to use
    // the webserver default set name = ''
    link.setAttribute('download', name);
    link.href = uri;
    document.body.appendChild(link);
    link.click();
    link.remove();
}

new download("0.1 beta","https://github.com/westothemagnificent/skitt")

new download("0.2 pre","https://github.com/westothemagnificent/skitt")