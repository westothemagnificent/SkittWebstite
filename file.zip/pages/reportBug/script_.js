const logo =  document.getElementsByClassName("logo")[0];
const reportBug =  document.getElementsByClassName("reportBug")[0];
const bugDorpDown =  document.getElementsByClassName("bugDropDown")[0];

logo.onclick = (event) => {
    document.location.href = "https://skitt.glitch.me/"
}

bugDorpDown.onchange = (event) => {
     let inputText = event.target.value;
      if(inputText == "4"){
        reportBug.style.backgroundColor  = "red";
      }
    if(inputText == "3"){
       reportBug.style.backgroundColor  = "orange";
     }
    if(inputText == "2"){
       reportBug.style.backgroundColor  = "yellow";
     }
    if(inputText == "1"){
       reportBug.style.backgroundColor  = "green";
    }
 }