const softwareDropDown = document.getElementById("softwareDropDown");
const logo =  document.getElementsByClassName("logo")[0];

logo.onclick = (event) => {
    document.location.href = "https://skitt.glitch.me/"
}


softwareDropDown.onchange = (event) => {
     let inputText = event.target.value;
     if(inputText == "skitt"){
       document.location.href = document.location + "/../../pages/downloadSkittPage"
     }
 }