const logo =  document.getElementsByClassName("logo")[0];

logo.onclick = (event) => {
    document.location.href = "https://skitt.glitch.me/"
}